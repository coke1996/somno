<?php

$host = "152.74.29.160";
$port = "9001";
$db = "somno";
$user = "postgres";
$pass = "somno2019";

$conn = pg_connect("host='$host' port='9001' dbname='$db' user='$user' password='$pass'");
?>