from django.contrib import admin
from somnowebApp.models import Muestra, Sabana

# Register your models here.

admin.site.register(Muestra)
admin.site.register(Sabana)
