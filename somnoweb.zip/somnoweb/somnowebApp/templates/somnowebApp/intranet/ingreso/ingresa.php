<?php
session_start();
$id_user = $_SESSION['rut_user'];
if(isset($_POST['nombre'])){
	if(isset($_POST['clave1'])){
		$nombre = $_POST['nombre'];
		$clave  = $_POST['clave1'];

		require("./../../conexion.php");

		$sql1 = "SELECT id FROM usuario WHERE rut='$id_user';";
		$res = pg_query($conn,$sql1);
		while($row = pg_fetch_array($res)){
			$id_bd = $row[0];
		}

		$sql = "INSERT INTO sabana (id,nombre_representativo, password, id_usuario) VALUES ('$clave','$nombre','$clave','$id_bd');";
		if(pg_query($conn,$sql)){
			echo json_encode("ingresado");
		}
		else if(!pg_query($conn,$sql)){
			echo json_encode("error");
		}
	}
}
?>