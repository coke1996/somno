<?php
session_start();
if(isset($_SESSION['rut_user'])){

	require("./../../conexion.php");

	$response = array();
	$aux = 0;

	$sql = "SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,fecha_y_hora FROM muestra LIMIT 1";
	$result = pg_query($conn,$sql);
	while($row = pg_fetch_array($result)){
	    $response[0] = $row[0];
	    $response[1] = $row[1];
	    $response[2] = $row[2];
	    $response[3] = $row[3];
	    $response[4] = $row[4];
	    $response[5] = $row[5];
	    $response[6] = $row[6];
	    $response[7] = $row[7];
	    $response[8] = $row[8];
	    $response[9] = $row[9];
	    $response[10] = $row[10];
	    $response[11] = $row[11];
	    $response[12] = $row[12];
	    $response[13] = $row[13];
	    $response[14] = $row[14];
	    $response[15] = $row[15];
	    $response[16] = $row[16];
	    $response[17] = $row[17];
	    $response[18] = $row[18];
	    $response[19] = $row[19];
	    $response[20] = $row[20];
	    $response[21] = $row[21];
	    $response[22] = $row[22];
	    $response[23] = $row[23];
	    $response[24] = $row[24];



	}

	echo json_encode($response);

}

?>