<?php
session_start();
session_destroy();

echo "saliendo";
?>

<meta http-equiv='Refresh' content='1;url=./../index.html'>	