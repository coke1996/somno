var fractions = new Array();
fractions.push("2/6+2/6","7/10+13/10");

function addingFractions(fractions) {
    var aux = 0;
    var fractions2 = new Array();
    
    function recorre(element){

    	element1 = String(element);
        console.log(element1);
        
        var num1 = element1.charAt(0);
        var num2 = element1.charAt(4);
        var num3 = 0;
        var den1 = element1.charAt(2);
        var den2 = element1.charAt(6);
        var den3 = 0;
        var flagDen = 0;
        console.log(num1);
        console.log(num2);
        console.log(den1);
        console.log(den2);
        
        den3 = parseInt(den1)*parseInt(den2);
        num3 = parseInt(num1)*parseInt(den2) + parseInt(num2)*parseInt(den1);
        
        res = 0;
        res2 = 0;
        while(res == 0 && res2==0){
            if(den3%2 == 0 && num3%2 == 0){
                den3 = den3/2;
                num3 = num3/2;
                
            }
            else if(den3%3 == 0 && num3%3 == 0){
                den3 = den3/3;
                num3 = num3/3;
                
            }
            else{
                fractions2.push(num3+'/'+den3);
            }
        }       
      aux = aux+1;  
    }

    fractions.forEach(recorre);
    
    return fractions2;
}

var res = addingFractions(fractions);

console.log(res)