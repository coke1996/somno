<?php
session_start();
if(isset($_POST['rut'])) {
	if(isset($_POST['pass'])) {
		$rut = $_POST['rut'];
		$passwd = $_POST['pass'];

    require('./../conexion.php');

    $sql = "SELECT password,id FROM usuario WHERE rut='$rut'";
    $result = pg_query($conn,$sql);
    if(pg_num_rows($result)==0){
    	echo json_encode("no existe");
    }
    else{
    	while($row = pg_fetch_array($result)){
    	    $pass_db = $row[0];
        }
        if($pass_db==$passwd){
            $_SESSION['rut_user'] = $rut;
            $_SESSION['id_user'] = $row[1];
        	echo json_encode("correcto");
        }
        else if($pass_db != $passwd){
        	echo json_encode("invalidas");
        }
    }

	}
}
?>