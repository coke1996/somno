function comprueba(){
	var rut = document.getElementById("rut").value;
	var pass = document.getElementById("password").value;

	if (rut==""){
		M.toast({html : "No ha ingresado un rut", classes : "rounded"});
	}
	else if (pass==""){
		M.toast({html : "No ha ingresado una password", classes : "rounded"});
	}
	else{
		$.ajax({
			url : "../../../templates/somnowebApp/login/comprueba.php",
			type : "POST",
			dataType : "json",
			data : {
				rut : rut,
				pass : pass
			}
		})
		.done(function(response){
			if (response=="correcto"){
				location.href = "../../../templates/somnowebApp/login/cargando.html"
			}
			else if(response=="invalidas"){
				M.toast({html : "Credenciales inválidas", classes : "rounded"});

			}
			else if (response=="no existe"){
				M.toast({html : "Rut no registrado en el sistema", classes : "rounded"});
			}
		})
		.fail( function(jqXHR, textStatus, errorThrown){
    		    console.log(jqXHR);
	            console.log(textStatus);
	            console.log(errorThrown);
    	    })
	}
}