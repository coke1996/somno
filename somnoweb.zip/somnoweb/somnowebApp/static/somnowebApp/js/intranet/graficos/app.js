
function saca_datos(){
  $.ajax({
    url : "obtiene_grafico.php",
    dataType : "json"
  })
  .done(function(response){
    new Morris.Line({
      element: 'myfirstchart',
      data: [
        { year: response[24], value: response[0] },
        { year: response[24], value: response[1] },
        { year: response[24], value: response[2] },
        { year: response[24], value: response[3] },
        { year: response[24], value: response[4] },
        { year: response[24], value: response[5] },
        { year: response[24], value: response[6] },
        { year: response[24], value: response[7] },
        { year: response[24], value: response[8] },
        { year: response[24], value: response[9] },
        { year: response[24], value: response[10] },
        { year: response[24], value: response[11] },
        { year: response[24], value: response[12] },
        { year: response[24], value: response[13] },
        { year: response[24], value: response[14] },
        { year: response[24], value: response[15] },
        { year: response[24], value: response[16] },
        { year: response[24], value: response[17] },
        { year: response[24], value: response[18] },
        { year: response[24], value: response[19] },
        { year: response[24], value: response[20] },
        { year: response[24], value: response[21] },
        { year: response[24], value: response[22] },
        { year: response[24], value: response[23] },
        
      ],
      xkey: 'year',
      ykeys: ['value'],
      labels: ['Value']
    });
    new Morris.Line({
      element: 'myfirstchart2',
      data: [
        { year: response[24], value: response[0] },
        { year: response[24], value: response[1] },
        { year: response[24], value: response[2] },
        { year: response[24], value: response[3] },
        { year: response[24], value: response[4] },
        { year: response[24], value: response[5] },
        { year: response[24], value: response[6] },
        { year: response[24], value: response[7] },
        { year: response[24], value: response[8] },
        { year: response[24], value: response[9] },
        { year: response[24], value: response[10] },
        { year: response[24], value: response[11] },
        { year: response[24], value: response[12] },
        { year: response[24], value: response[13] },
        { year: response[24], value: response[14] },
        { year: response[24], value: response[15] },
        { year: response[24], value: response[16] },
        { year: response[24], value: response[17] },
        { year: response[24], value: response[18] },
        { year: response[24], value: response[19] },
        { year: response[24], value: response[20] },
        { year: response[24], value: response[21] },
        { year: response[24], value: response[22] },
        { year: response[24], value: response[23] },
        
      ],
      xkey: 'year',
      ykeys: ['value'],
      labels: ['Value']
    });
  }) 
}

saca_datos();

