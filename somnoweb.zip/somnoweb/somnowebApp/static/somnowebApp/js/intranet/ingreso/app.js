function registra(){
	var nombre = document.getElementById("nombre").value;
	var mac = document.getElementById("mac").value;    
	var clave1 = document.getElementById("password").value; 
	var clave2 = document.getElementById("password2").value; 

	if(nombre==""){
		M.toast({html : "No ha ingresado un nombre para su sábana", classes : "rounded"});
	}
	else if(mac==""){
		M.toast({html : "Debe ingresar una dirección MAC", classes : "rounded"});
	}
	else if(clave1==""){
		M.toast({html : "No ha ingresado una clave", classes : "rounded"});
	}
	else if(clave2==""){
		M.toast({html : "Por favor, confirme su clave", classes : "rounded"});
	}
	else if(clave1!=clave2){
		M.toast({html : "Las claves no coinciden", classes : "rounded"});
	}
	else if(clave1==clave2){
		$.ajax({
			url : "ingresa.php",
			type : "POST",
			dataType : "json",
			data : {
				nombre : nombre,
				clave1 : clave1
			}
		})
		.done(function(response){
			if(response=="ingresado"){
				document.getElementById("nombre").value = "";
				document.getElementById("password").value = "";
				document.getElementById("password2").value = "";
				M.toast({html : "Sabana correctamente ingresada", classes : "rounded"});
				location.href = "./../intranet.php";
			}
			else if (response=="error"){
				M.toast({html : "Ups, tuvimos un error al ingresar su sábana, por favor reintente en unso minutos", classes : "rounded"});
			}
		})
		.fail( function(jqXHR, textStatus, errorThrown){
    	   console.log(jqXHR);
	       console.log(textStatus);
	       console.log(errorThrown);
        })
	}

}
;



