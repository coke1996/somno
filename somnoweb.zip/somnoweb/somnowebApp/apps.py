from django.apps import AppConfig


class SomnowebappConfig(AppConfig):
    name = 'somnowebApp'
