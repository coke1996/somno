from django.urls import path
from somnowebApp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.Home, name="Home"),
    path('login/', views.Login, name="Ingresar"),
    path('intranet/', views.Intranet, name="Intranet Somno"),
    path('graficos/', views.Graficos, name = "Graficos en Tiempo Real"),
    path('ingresa_sabana/', views.Ingresa_Sabana, name = "Ingresar Sabana"),
    
]

urlpatterns+=static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)