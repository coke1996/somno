from django.shortcuts import render, HttpResponse

# Create your views here.

def Home(request):

    return render(request, "somnowebApp/index.html")


def Login(request):

    return render(request, "somnowebApp/login/login.html")


def Intranet(request):

    return render(request, "somnowebApp/intranet/intranet.php")

def Ingresa_Sabana(request):

    return render(request, "somnowebApp/intranet/ingreso/ingresa_sabana.html")

def Graficos(request):

    return render(request, "somnowebApp/intranet/graficos/general.html")